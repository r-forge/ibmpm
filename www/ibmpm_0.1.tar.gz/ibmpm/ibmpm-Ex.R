pkgname <- "ibmpm"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
options(pager = "console")
library('ibmpm')

assign(".oldSearch", search(), pos = 'CheckExEnv')
cleanEx()
nameEx("ibmpm")
### * ibmpm

flush(stderr()); flush(stdout())

### Name: metapop
### Title: Metapopulation simulation
### Aliases: metapop
### Keywords: simulation

### ** Examples

# TODO




cleanEx()
nameEx("pop.model")
### * pop.model

flush(stderr()); flush(stdout())

### Name: pop.model
### Title: Population models
### Aliases: pop.model tr.exp.growth logistic.growth ext.logistic.growth
###   st.logistic.growth gst.logistic.growth
### Keywords: simulation

### ** Examples


popmods <- c("tr.exp.growth", "logistic.growth", "st.logistic.growth",
			 "gst.logistic.growth", "ext.logistic.growth")

clr <- structure(seq_along(popmods), names = popmods)

RNGkind("Mersenne")
set.seed(17)
l <- 500
k <- 100
r <- 1.05
plot(c(0, l), c(0, k), xlab = "time", ylab = "population size",
	 type = "n", ylim = c(0, k * 1.05), yaxs = "i", axes = FALSE)
axis(1)
axis(2, c(0, k / c(2,1)), labels = c(0, "K/2", "K"), las = 1)
box()
for(pm in popmods) {
	x <- numeric(l)
	x[1] <- 1
	for(i in 2:l) x[i] <- x[i - 1] * get(pm)(x[i - 1], r, k, t = i,
		r.prop = .95, ext.interval = 20, shape = .001, rate = 1)
	lines(1:l, x, col = clr[pm])
}
abline(h = c(0, k), lty= 3)
legend("bottomright", popmods, text.col = clr, cex = .75,
	   title = "Function:", title.adj = 0.1, lty = 1, col = clr,
	   bg = "white")





cleanEx()
nameEx("read.structure")
### * read.structure

flush(stderr()); flush(stdout())

### Name: read.structure
### Title: Read 'Structure' data file
### Aliases: read.structure
### Keywords: data

### ** Examples



#read example file:
dat <- read.structure(system.file(package = "ibmpm", "examples", "structure.txt"))

# infer sex from rownames
dat$sex <- factor(gsub("^.*([MF])[0-9]+$", "\\1", rownames(dat), perl = TRUE),
		levels = c("F", "M"))

head(dat)

n.patch <- max(dat$patch)
# random dispersal matrix
disp.mat <- array(runif(n.patch^2), dim = c(n.patch, n.patch))

dat <- metapop(disp.mat, dat, sim.len = 20, n.offspring = 5, carr.cap = 100)





### * <FOOTER>
###
cat("Time elapsed: ", proc.time() - get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
